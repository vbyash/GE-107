# animated-sniffle_esp32
//this is a people counting project that uses wifi signals to detect the number of people in the desired range of esp32(nodemcu)//
