const char* ssid     = "CHENAB";         // The SSID (name) of the Wi-Fi network you want to connect to
const char* password = "44zMf3QqdU&KC3Mv";

const char* mqttServer = "broker.emqx.io";
const int mqttPort = 1883;
const char* mqttUser = "emqx";
const char* mqttPassword = "public";